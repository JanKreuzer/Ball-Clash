using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Player : MonoBehaviour
{
    public KeyCode keycode;
    public KeyCode keycodereset;
    public int newforce = 10;
    public GameObject wurfding;
    public Image lebensleiste;
    public GameManager manager;
    public int dir;
    public int leben = 10;
    public Text lebentext;
    public AudioClip clip;
    public bool once = false;
    public int resetcounter = 0;
    public Button toutchinterface;
    int force;


    // Start is called before the first frame update
    void Start()
        {
            lebentext.text = leben.ToString();
        }

    // Update is called once per frame
    void Update()
        { 
            if(manager.gamekeys==false) return;

            if(resetcounter==6)
                {
                    manager.restart=false;
                    resetcounter=0;
                }

            if (Input.GetKey(keycode))
                {
                    force = force+newforce;
                }

            if (Input.GetKeyUp(keycode))
                {
                    GameObject ding = Instantiate(wurfding, transform.position+(new Vector3(4*dir,0,0)), Quaternion.identity);
                    ding.GetComponent<Rigidbody>().AddForce(new Vector3(force*dir,force,0));
                    force=0;
                    Destroy(ding,10);
                }

            if (Input.GetKeyUp(keycodereset))
                {
                    leben=0;
                }

            if(leben<1)
                {
                    gameObject.SetActive(false);
                }
        }
   
    void OnCollisionEnter(Collision collision)
        {
            lebensleiste.fillAmount= lebensleiste.fillAmount-0.1F;
            Destroy(collision.gameObject);
            leben=leben-1;
            lebentext.text = leben.ToString();
            AudioSource.PlayClipAtPoint(clip,transform.position);
            once=false;
        }
} 
