using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject[] players_1;
    public GameObject[] players_2;
    public GameObject[] players_3;
    public GameObject[] playersG;
    public GameObject[] playersR;
    public GameObject gameOverPanelGG;
    public GameObject gameOverPanelRG;
    public GameObject gameOverPanelUnentschieden;
    public GameObject credits;
    public GameObject gamepanel;
    public GameObject startpanel;
    bool isgameoverR = false; 
    bool isgameoverG = false;
    public bool gamekeys = false;
    public bool restart = false;
    public bool non_plot_twist = false;
    public int player_counter_1 = 0;
    public int player_counter_2 = 0;
    public int player_counter_3 = 0;
   
    //Start is called before the first frame update
    void Start()
        {
            startpanel.SetActive(true);
            gamepanel.SetActive(false);
            gameOverPanelGG.SetActive(false);
            gameOverPanelRG.SetActive(false);
            gameOverPanelUnentschieden.SetActive(false);
            credits.SetActive(false);
        }
    
    void Update()
        {      
//non plot twist checker
            if(credits.activeInHierarchy) return;
            if(startpanel.activeInHierarchy) return;

            isgameoverR=true;
            isgameoverG=true;

            for(int i = 0; i < playersG.Length; i++)
            {
                if(playersG[i].activeInHierarchy)
                {
                    isgameoverG= false;
                    break;
                }
            }

            for(int i = 0; i < playersR.Length; i++)
            {
                if(playersR[i].activeInHierarchy)
                {
                    isgameoverR= false;
                    break;
                }
            }

            if (isgameoverG==true)
            {
                gameOverPanelRG.SetActive(true);
                gamepanel.SetActive(false);
                gameOverPanelUnentschieden.SetActive(false);
                gamekeys=false;
                non_plot_twist=true;
            }

            if (isgameoverR==true)
            {
                gameOverPanelGG.SetActive(true);
                gamepanel.SetActive(false);
                gameOverPanelUnentschieden.SetActive(false);
                gamekeys=false;
                non_plot_twist=true;
            }

 // es wird kompliziert potttwist checker
            for(int i = 0; i < players_1.Length; i++)
            {
                if(players_1[i].activeInHierarchy)
                {
                    player_counter_1++;
                }
            }

            for(int i = 0; i < players_2.Length; i++)
            {
                if(players_2[i].activeInHierarchy)
                {
                    player_counter_2++;
                }
            }

            for(int i = 0; i < players_3.Length; i++)
            {
                if(players_3[i].activeInHierarchy)
                {
                    player_counter_3++;
                }
            }

            if(player_counter_1<2&&player_counter_2<2&&player_counter_3<2&&non_plot_twist==false)
                {
                    gameOverPanelUnentschieden.SetActive(true);
                }

            player_counter_1=0;
            player_counter_2=0;
            player_counter_3=0;
        }

public void Quit()
    {
        Application.Quit();
        Debug.Log("quit!");
    }

public void Credits()
    {
        gameOverPanelGG.SetActive(false);
        gameOverPanelRG.SetActive(false);
        gamepanel.SetActive(false);
        gameOverPanelUnentschieden.SetActive(false);
        startpanel.SetActive(false);
        credits.SetActive(true);
        gamekeys=false;
    }

public void MainMenu()
    {
        gameOverPanelGG.SetActive(false);
        gameOverPanelRG.SetActive(false);
        gameOverPanelUnentschieden.SetActive(false);
        gamepanel.SetActive(false);
        startpanel.SetActive(true);
        credits.SetActive(false);
        gamekeys=false;
    }

public void Restart()
    {
        isgameoverR= true;
        isgameoverG= true;
        gamekeys = true;
        restart=true;
        non_plot_twist=false;
        player_counter_1=0;
        player_counter_2=0;
        player_counter_3=0;
        startpanel.SetActive(false);
        gamepanel.SetActive(true);
        gameOverPanelGG.SetActive(false);
        gameOverPanelRG.SetActive(false);
        gameOverPanelUnentschieden.SetActive(false);
        credits.SetActive(false);
        GameObject[] objectsToDestroy = GameObject.FindGameObjectsWithTag("tagwurfding");
        foreach(GameObject go in objectsToDestroy) 
            {
                Destroy(go);
            }
        
        for(int i = 0; i < playersG.Length; i++)
            {
                playersG[i].SetActive(true);
                playersG[i].GetComponent<Player>().leben=10;
                playersG[i].GetComponent<Player>().lebensleiste.fillAmount= 1F;
                
            }

        for(int i = 0; i < playersR.Length; i++)
            {
                playersR[i].SetActive(true);
                playersR[i].GetComponent<Player>().leben=10;
                playersR[i].GetComponent<Player>().lebensleiste.fillAmount= 1F;
            }
    }
}
